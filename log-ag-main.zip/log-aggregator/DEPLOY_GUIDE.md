# Log Aggregator — AWS Deployment Guide
## End-to-End CI/CD: S3 → CodeBuild → ECR → CodeDeploy → ECS Fargate + Lambda

---

## Architecture Overview

```
Developer uploads ZIP
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│  S3: log-aggregator-source-zip/log-ag-main.zip                  │
│  (versioning enabled — each upload = new pipeline trigger)      │
└───────────────┬─────────────────────────────────────────────────┘
                │ S3 event triggers CodePipeline
                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 1: SOURCE                                                 │
│  CodePipeline pulls ZIP, stores as SourceArtifact in S3         │
└───────────────┬─────────────────────────────────────────────────┘
                │
                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 2: BUILD  (CodeBuild — buildspec.yml)                     │
│  • ECR login                                                     │
│  • Run pytest (fail-fast on test failure)                        │
│  • docker build × 4 images (app, processor, dashboard, chatbot) │
│  • docker push all images to ECR                                 │
│  • Package Lambda ZIP → upload to S3                             │
│  • Emit imagedefinitions-*.json + lambda-artifact.json          │
└───────────────┬─────────────────────────────────────────────────┘
                │ BuildArtifact passed downstream
                ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 3: DEPLOY  (parallel)                                     │
│  ┌──────────────────────────────┐  ┌───────────────────────────┐│
│  │ 3a. CodeBuild                │  │ 3b/c/d. CodeDeploy (ECS)  ││
│  │ (buildspec-deploy.yml)       │  │ Blue/Green per service:   ││
│  │ • Register ECS task defs     │  │ • App service             ││
│  │ • Update Lambda code         │  │ • Dashboard service       ││
│  │ • Publish Lambda version     │  │ • Chatbot service         ││
│  │ • Update "live" alias        │  └───────────────────────────┘│
│  └──────────────────────────────┘                               │
└─────────────────────────────────────────────────────────────────┘
                │
                ▼
        Traffic shifted to new ECS tasks (blue/green)
        Lambda alias "live" → new version
```

---

## Prerequisites

Create these resources **once** before deploying the pipeline:

### 1. S3 Buckets

```bash
# Source bucket — where you upload your ZIP
aws s3 mb s3://log-aggregator-source-zip --region us-east-1
aws s3api put-bucket-versioning \
  --bucket log-aggregator-source-zip \
  --versioning-configuration Status=Enabled

# Pipeline artifact store
aws s3 mb s3://log-aggregator-pipeline-artifacts --region us-east-1
aws s3api put-bucket-versioning \
  --bucket log-aggregator-pipeline-artifacts \
  --versioning-configuration Status=Enabled

# Raw logs + Lambda packages
aws s3 mb s3://log-aggregator-raw-logs --region us-east-1
```

### 2. ECR Repositories

```bash
for repo in app processor dashboard chatbot; do
  aws ecr create-repository \
    --repository-name log-aggregator/$repo \
    --region us-east-1
done
```

### 3. Secrets Manager

```bash
aws secretsmanager create-secret \
  --name log-aggregator/bedrock \
  --region us-east-1 \
  --secret-string '{
    "BEDROCK_AGENT_ID": "YOUR_AGENT_ID",
    "BEDROCK_AGENT_ALIAS_ID": "YOUR_ALIAS_ID"
  }'
```

### 4. IAM Roles

Apply the four policies in `iam/iam-policies.json` and attach them to these roles:

| Role Name                          | Policies Attached                       | Used By              |
|------------------------------------|-----------------------------------------|----------------------|
| `log-aggregator-ecs-execution-role`| `log-aggregator-ecs-execution-policy`   | ECS Fargate agent    |
| `log-aggregator-ecs-task-role`     | `log-aggregator-ecs-task-policy`        | App code in container|
| `log-aggregator-codebuild-role`    | `log-aggregator-codebuild-policy`       | CodeBuild projects   |
| `log-aggregator-codepipeline-role` | `log-aggregator-codepipeline-policy`    | CodePipeline         |

**Quick creation:**
```bash
# ECS execution role trust policy
cat > /tmp/ecs-trust.json << 'TRUST'
{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ecs-tasks.amazonaws.com"},"Action":"sts:AssumeRole"}]}
TRUST

aws iam create-role --role-name log-aggregator-ecs-execution-role \
  --assume-role-policy-document file:///tmp/ecs-trust.json

# Repeat for task role, CodeBuild role (codebuild.amazonaws.com), pipeline role (codepipeline.amazonaws.com)
```

### 5. ECS Cluster + Services (with ALB)

```bash
# Create cluster
aws ecs create-cluster --cluster-name log-aggregator-cluster

# Services must already exist before CodeDeploy can do blue/green.
# Create them via the AWS Console or CloudFormation with:
#   - DeploymentController: { Type: CODE_DEPLOY }
#   - Load balancer with two target groups (blue + green)
#   - Test listener on port 8080, production listener on port 80/443
```

---

## Deploying the Pipeline

### Step 1 — Update Placeholders

Replace `ACCOUNT_ID` and `REGION` across all files:

```bash
ACCOUNT_ID="123456789012"
REGION="us-east-1"

# Task definitions
sed -i "s/ACCOUNT_ID/$ACCOUNT_ID/g; s/REGION/$REGION/g" ecs/taskdef-*.json

# IAM policies
sed -i "s/ACCOUNT_ID/$ACCOUNT_ID/g" iam/iam-policies.json

# CodeDeploy deployment groups in codepipeline.yml
sed -i "s/ACCOUNT_ID/$ACCOUNT_ID/g" codepipeline.yml
```

### Step 2 — Deploy the CloudFormation Stack

```bash
aws cloudformation deploy \
  --template-file codepipeline.yml \
  --stack-name log-aggregator-pipeline \
  --region us-east-1 \
  --capabilities CAPABILITY_NAMED_IAM \
  --parameter-overrides \
    AWSAccountId=$ACCOUNT_ID \
    AWSRegion=us-east-1 \
    CodeBuildRoleArn=arn:aws:iam::$ACCOUNT_ID:role/log-aggregator-codebuild-role \
    CodePipelineRoleArn=arn:aws:iam::$ACCOUNT_ID:role/log-aggregator-codepipeline-role \
    ECSExecutionRoleArn=arn:aws:iam::$ACCOUNT_ID:role/log-aggregator-ecs-execution-role \
    ECSTaskRoleArn=arn:aws:iam::$ACCOUNT_ID:role/log-aggregator-ecs-task-role
```

### Step 3 — Upload the Source ZIP to S3

This triggers the pipeline automatically:

```bash
aws s3 cp log-aggregator.zip \
  s3://log-aggregator-source-zip/log-ag-main.zip
```

**That's the only step you repeat for every deployment.**

---

## CI/CD Flow — Detailed

### Stage 1: Source
CodePipeline polls (or reacts to EventBridge notification) for changes to
`s3://log-aggregator-source-zip/log-ag-main.zip`. When a new version is
detected, CodePipeline copies the ZIP to the artifact bucket and starts the
pipeline. CodePipeline **automatically unzips** the source artifact before
passing it to CodeBuild — your `buildspec.yml` receives the extracted files
directly.

### Stage 2: Build (`buildspec.yml`)

1. **Install** — pip, awscli, Docker BuildKit enabled
2. **Pre-build** — ECR login, detect nested path (handles deep folder structures), set `IMAGE_TAG` to short commit SHA or timestamp
3. **Tests** — `pytest tests/` with JUnit XML report; build aborts on failure
4. **Build** — four Docker image builds using `--cache-from` to speed up subsequent builds:
   - `dockerfiles/Dockerfile.app` → `ECR_APP_URI:$IMAGE_TAG`
   - `dockerfiles/Dockerfile.processor` → `ECR_PROCESSOR_URI:$IMAGE_TAG`
   - `dockerfiles/Dockerfile.dashboard` → `ECR_DASHBOARD_URI:$IMAGE_TAG`
   - `dockerfiles/Dockerfile.chatbot` → `ECR_CHATBOT_URI:$IMAGE_TAG`
5. **Lambda packaging** — installs Conversion deps into `/tmp/lambda-pkg/`, zips with `lambda_handler.py`, uploads to `s3://RAW_LOGS_BUCKET/lambda/log-processor-$IMAGE_TAG.zip`
6. **Post-build** — pushes all 4 images + `latest` tags to ECR, writes `imagedefinitions-*.json` and `lambda-artifact.json` as downstream artifacts

### Stage 3a: Deploy (`buildspec-deploy.yml`)

1. Reads `IMAGE_TAG` from `lambda-artifact.json`
2. `sed` replaces `IMAGE_TAG_PLACEHOLDER` in each `ecs/taskdef-*.json`
3. Calls `aws ecs register-task-definition` for app, dashboard, chatbot — captures new revision ARNs
4. Renders `appspec-ecs-app.yml` and `appspec-ecs-dashboard.yml` with real task definition ARNs
5. Calls `aws lambda update-function-code` → `aws lambda publish-version` → `aws lambda update-alias` (creates `live` alias if missing)

### Stage 3b: Deploy (CodeDeploy Blue/Green)

CodeDeploy reads the `appspec-ecs-app.yml` produced by 3a and:
1. Creates a new **green** task set on the ECS service with the new task definition
2. Invokes `log-aggregator-pretraffic-hook` Lambda (health check on new task set)
3. Shifts production traffic from blue → green via ALB target group swap
4. Invokes `log-aggregator-posttraffic-hook` Lambda (emits `SuccessfulDeployment` metric)
5. Terminates the old blue task set after a 5-minute wait

---

## ECS Task Definitions

Each service has its own task definition in `ecs/`:

| File                    | Container | Port | CPU  | Memory |
|-------------------------|-----------|------|------|--------|
| `taskdef-app.json`      | `app`     | 5000 | 512  | 1024MB |
| `taskdef-dashboard.json`| `dashboard`| 5000| 512  | 1024MB |
| `taskdef-chatbot.json`  | `chatbot` | 5000 | 512  | 1024MB |

**Secrets injection:** The task definitions pull `BEDROCK_AGENT_ID` and
`BEDROCK_AGENT_ALIAS_ID` directly from Secrets Manager at container start
via the `secrets` block. Your application code reads `os.environ` — no SDK
calls needed, no credentials in the image.

```json
"secrets": [
  {
    "name": "BEDROCK_AGENT_ID",
    "valueFrom": "arn:aws:secretsmanager:...:log-aggregator/bedrock:BEDROCK_AGENT_ID::"
  }
]
```

**CloudWatch Logs:** All containers write to `/ecs/log-aggregator/<service>`.
`awslogs-create-group: true` ensures the log group is auto-created.

---

## Calling Bedrock from ECS

See `scripts/bedrock_from_ecs_example.py` for the complete annotated pattern.
The key flow:

```
Secrets Manager
    │  (ECS agent reads secret at container start using Execution Role)
    ▼
Environment Variables (BEDROCK_AGENT_ID, BEDROCK_AGENT_ALIAS_ID)
    │  (your code reads os.environ — no boto3 secrets call needed)
    ▼
Application code calls bedrock-agent-runtime via boto3
    │  (boto3 picks up Task Role credentials from container metadata endpoint)
    ▼
Bedrock Agent responds (streamed EventStream)
```

No static credentials anywhere. No API keys in the image.

---

## Lambda Deployment

**Packaging** (handled by `buildspec.yml`):
```
Conversion/log_parser.py
Conversion/log_to_csv_service.py
lambda/lambda_handler.py
+ pip-installed deps from Conversion/requirements.txt
→ log-processor-$IMAGE_TAG.zip → s3://log-aggregator-raw-logs/lambda/
```

**Versioning strategy:**
- Every deployment publishes a new numbered version (`$LATEST` is never used in prod)
- The `live` alias always points to the latest deployed version
- Invoke the function as `log-aggregator-processor:live` for production traffic
- CodeDeploy shifts traffic to the new version using `LambdaLinear10PercentEvery1Minute`

**Lifecycle hooks** (`lambda/deployment_hooks.py`):
- `BeforeAllowTraffic` → `pretraffic_hook`: hits health endpoint, reports Succeeded/Failed to CodeDeploy
- `AfterAllowTraffic` → `posttraffic_hook`: emits CloudWatch metric, always Succeeded

---

## File Reference

```
log-aggregator/
├── buildspec.yml              ← CodeBuild: build + test + ECR push + Lambda package
├── buildspec-deploy.yml       ← CodeBuild: register task defs + update Lambda
├── codepipeline.yml           ← CloudFormation: full pipeline definition
│
├── codedeploy/
│   ├── appspec-ecs.yml        ← CodeDeploy template for ECS blue/green
│   └── appspec-lambda.yml     ← CodeDeploy for Lambda traffic shifting
│
├── ecs/
│   ├── taskdef-app.json       ← ECS task def: Flask app
│   ├── taskdef-dashboard.json ← ECS task def: Dashboard service
│   └── taskdef-chatbot.json   ← ECS task def: Bedrock chatbot
│
├── dockerfiles/
│   ├── Dockerfile.app         ← Flask app + Conversion + Dashboard (multi-stage)
│   ├── Dockerfile.processor   ← Lambda-style log processor container
│   ├── Dockerfile.dashboard   ← Dashboard service
│   └── Dockerfile.chatbot     ← Bedrock-backed chatbot service
│
├── lambda/
│   ├── lambda_handler.py      ← S3-triggered log processing function
│   └── deployment_hooks.py    ← PreTraffic + PostTraffic CodeDeploy hooks
│
├── iam/
│   └── iam-policies.json      ← All 4 IAM policies (execution, task, codebuild, pipeline)
│
├── scripts/
│   └── bedrock_from_ecs_example.py  ← Annotated Bedrock-from-ECS pattern
│
├── Application/               ← Flask app source (unchanged)
├── Conversion/                ← Log parser + CSV service (unchanged)
├── Dashboard/                 ← Dashboard blueprint + Bedrock service (unchanged)
└── tests/                     ← Pytest test suite (run in build phase)
```

---

## Triggering a Deployment

```bash
# Package and upload — this starts the full pipeline automatically
zip -r log-aggregator.zip log-aggregator/ -x "*.pyc" -x "__pycache__/*" -x ".coverage"
aws s3 cp log-aggregator.zip s3://log-aggregator-source-zip/log-ag-main.zip
```

Monitor in the AWS Console under **CodePipeline → log-aggregator-pipeline**.
