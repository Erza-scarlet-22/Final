"""
bedrock_from_ecs_example.py
═══════════════════════════════════════════════════════════════════════════════
COMPLETE PATTERN: Calling AWS Bedrock from an ECS Fargate container
with credentials injected from Secrets Manager.

HOW SECRETS REACH THE CONTAINER (no code change needed for secret fetching):
──────────────────────────────────────────────────────────────────────────────
1. Secrets are stored in AWS Secrets Manager as a JSON object:
       Secret name : log-aggregator/bedrock
       Secret value: {"BEDROCK_AGENT_ID": "ABCDEF123",
                      "BEDROCK_AGENT_ALIAS_ID": "TSTALIASID"}

2. The ECS task definition "secrets" block maps secret fields → env vars:
       "secrets": [
         {
           "name": "BEDROCK_AGENT_ID",
           "valueFrom": "arn:aws:secretsmanager:...:log-aggregator/bedrock:BEDROCK_AGENT_ID::"
         },
         ...
       ]

3. When ECS starts the container, the ECS agent (using the Task Execution Role)
   calls Secrets Manager and injects the values as environment variables.
   Your application code simply reads os.environ — no SDK call needed.

4. The container itself (Task Role) calls Bedrock using boto3 with the
   IAM role attached to the task — no static API keys anywhere.

REQUIRED IAM PERMISSIONS:
──────────────────────────────────────────────────────────────────────────────
Task EXECUTION role (used by ECS agent):
  - secretsmanager:GetSecretValue  on log-aggregator/bedrock secret

Task ROLE (used by your application code):
  - bedrock:InvokeAgent            on arn:aws:bedrock:*:*:agent/*
  - bedrock:InvokeModel            on foundation model ARNs (if using direct model)
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import logging
import os
from typing import Dict, List, Optional
from uuid import uuid4

import boto3
from botocore.config import Config

logger = logging.getLogger(__name__)
logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))


# ─────────────────────────────────────────────────────────────────────────────
# 1. Reading Bedrock credentials from environment (injected by ECS from Secrets
#    Manager — no boto3 call needed, just os.environ)
# ─────────────────────────────────────────────────────────────────────────────

def get_bedrock_config() -> Dict[str, str]:
    """
    Read Bedrock configuration from environment variables.
    These are injected by ECS from Secrets Manager at container start.
    Raises RuntimeError if required variables are missing.
    """
    agent_id       = os.environ.get("BEDROCK_AGENT_ID")
    agent_alias_id = os.environ.get("BEDROCK_AGENT_ALIAS_ID")
    region         = os.environ.get("AWS_REGION", os.environ.get("AWS_DEFAULT_REGION", "us-east-1"))

    if not agent_id or not agent_alias_id:
        raise RuntimeError(
            "BEDROCK_AGENT_ID and BEDROCK_AGENT_ALIAS_ID must be set. "
            "These are injected from Secrets Manager via the ECS task definition."
        )

    return {
        "agent_id":       agent_id,
        "agent_alias_id": agent_alias_id,
        "region":         region,
    }


# ─────────────────────────────────────────────────────────────────────────────
# 2. Creating the boto3 Bedrock client
#    boto3 automatically uses the ECS Task Role credentials via the
#    container metadata endpoint — no explicit credential configuration needed.
# ─────────────────────────────────────────────────────────────────────────────

def get_bedrock_agent_client(region: str):
    """
    Returns a boto3 bedrock-agent-runtime client.
    Credentials come automatically from the ECS Task Role (instance metadata).
    """
    return boto3.client(
        "bedrock-agent-runtime",
        region_name=region,
        config=Config(
            retries={"max_attempts": 3, "mode": "adaptive"},
            read_timeout=120,
            connect_timeout=10,
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# 3. Calling the Bedrock Agent — mirrors bedrock_chat_service.py in Dashboard/
# ─────────────────────────────────────────────────────────────────────────────

def call_bedrock_agent(
    user_message: str,
    error_details: Optional[Dict] = None,
    session_id: Optional[str] = None,
) -> Dict:
    """
    Send a message to the Bedrock Agent and return its response.

    Args:
        user_message:  The user's question/input.
        error_details: Optional structured log error context dict.
        session_id:    Reuse an existing session (omit to start a new one).

    Returns:
        {
            "response_text": str,
            "session_id":    str,
            "citations":     list,
        }
    """
    config = get_bedrock_config()
    client = get_bedrock_agent_client(config["region"])

    # Build the full prompt
    prompt = _build_prompt(user_message, error_details or {})
    session_id = session_id or str(uuid4())

    logger.info(
        "Invoking Bedrock Agent %s (alias %s), session %s",
        config["agent_id"], config["agent_alias_id"], session_id,
    )

    response = client.invoke_agent(
        agentId=config["agent_id"],
        agentAliasId=config["agent_alias_id"],
        sessionId=session_id,
        inputText=prompt,
        enableTrace=False,
    )

    # The response is a streaming EventStream — collect all chunks
    full_text = ""
    citations = []

    for event in response.get("completion", []):
        if "chunk" in event:
            chunk = event["chunk"]
            if "bytes" in chunk:
                full_text += chunk["bytes"].decode("utf-8")
            if "attribution" in chunk:
                citations.extend(chunk["attribution"].get("citations", []))

    logger.info("Bedrock response length: %d chars", len(full_text))
    return {
        "response_text": full_text.strip(),
        "session_id":    session_id,
        "citations":     citations,
    }


def _build_prompt(user_message: str, error_details: Dict) -> str:
    """Compose the full prompt string for the Bedrock Agent."""
    error_block = ""
    if error_details:
        error_block = (
            "Selected error context:\n"
            f"- Status Code: {error_details.get('Status Code', 'N/A')}\n"
            f"- Error Code:  {error_details.get('Error Code', 'N/A')}\n"
            f"- Description: {error_details.get('Description', 'N/A')}\n"
            f"- API:         {error_details.get('API', 'N/A')}\n"
            f"- Count:       {error_details.get('Count', 'N/A')}\n"
            f"- Last Seen:   {error_details.get('Last Seen', 'N/A')}\n\n"
        )

    return (
        "You are an API incident triage assistant. Provide concise root cause "
        "analysis, immediate remediation steps, and prevention recommendations. "
        "Respond in plain text only.\n\n"
        f"{error_block}"
        f"User question:\n{user_message.strip()}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# 4. Alternative: calling a Bedrock Foundation Model directly (no agent needed)
# ─────────────────────────────────────────────────────────────────────────────

def call_bedrock_model_direct(prompt: str, model_id: str = "anthropic.claude-3-sonnet-20240229-v1:0") -> str:
    """
    Invoke a Bedrock foundation model directly using the Messages API.
    Useful when you don't have a configured Bedrock Agent.
    """
    region = os.environ.get("AWS_REGION", "us-east-1")
    client = boto3.client(
        "bedrock-runtime",
        region_name=region,
        config=Config(retries={"max_attempts": 3, "mode": "adaptive"}),
    )

    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens":        1024,
        "messages": [
            {"role": "user", "content": prompt}
        ],
    })

    response = client.invoke_model(
        modelId=model_id,
        contentType="application/json",
        accept="application/json",
        body=body,
    )

    result = json.loads(response["body"].read())
    return result["content"][0]["text"]


# ─────────────────────────────────────────────────────────────────────────────
# 5. Quick smoke test (run locally or as a container CMD)
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    try:
        result = call_bedrock_agent(
            user_message="What are the most common causes of HTTP 503 errors in microservices?",
            error_details={
                "Status Code": "503",
                "Error Code": "SERVICE_UNAVAILABLE",
                "Description": "Upstream timeout from payment gateway",
                "API": "/api/v1/payments",
                "Count": 42,
                "Last Seen": "2024-01-15T14:32:00Z",
            },
        )
        print("=== Bedrock Response ===")
        print(result["response_text"])
        print(f"\nSession ID: {result['session_id']}")
    except RuntimeError as e:
        print(f"Config error: {e}")
        print("Make sure BEDROCK_AGENT_ID and BEDROCK_AGENT_ALIAS_ID are set.")
